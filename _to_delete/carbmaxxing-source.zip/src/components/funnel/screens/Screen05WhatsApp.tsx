"use client";

import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { BadgeCheck, Phone, User, Video } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { ArrowRight } from "../icons";
import { cn } from "@/lib/utils";
import type { FunnelScreenProps } from "../types";

/**
 * Roteiro do chat. No Figma essas mensagens estavam repetidas como
 * placeholder de layout — troque pelo roteiro real de prova social /
 * quebra de objeção que você quer simular aqui.
 */
const SCRIPT: { from: "friend" | "me"; text: string; time: string }[] = [
  { from: "friend", text: "Eu preparei uma parada especial\npra 50 pessoas que entrassem", time: "21:27" },
  { from: "friend", text: "Eu preparei uma parada especial\npra 50 pessoas que entrassem", time: "21:27" },
  { from: "friend", text: "Eu preparei uma parada especial\npra 50 pessoas que entrassem", time: "21:27" },
  { from: "friend", text: "Eu preparei uma parada especial\npra 50 pessoas que entrassem", time: "21:27" },
  { from: "friend", text: "Eu preparei uma parada especial\npra 50 pessoas que entrassem", time: "21:27" },
  { from: "friend", text: "Eu preparei uma parada especial\npra 50 pessoas que entrassem", time: "21:27" },
  { from: "friend", text: "Me desculpa de verdade", time: "21:27" },
  { from: "me", text: "Com certeza! 🚀", time: "07:12" },
  { from: "friend", text: "Me desculpa de verdade", time: "21:27" },
  { from: "friend", text: "Me desculpa de verdade", time: "21:27" },
  { from: "friend", text: "Me desculpa de verdade", time: "21:27" },
  { from: "friend", text: "Me desculpa de verdade", time: "21:27" },
];

const STEP_DELAY = 550;
const TYPING_DELAY = 750;

export function Screen05WhatsApp({ onNext, onBack }: FunnelScreenProps) {
  const [visibleCount, setVisibleCount] = useState(0);
  const [typing, setTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (visibleCount >= SCRIPT.length) return;

    const next = SCRIPT[visibleCount];
    const showTyping = next.from === "friend";

    const startTypingTimer = showTyping
      ? window.setTimeout(() => setTyping(true), 0)
      : undefined;

    const revealTimer = window.setTimeout(
      () => {
        setTyping(false);
        setVisibleCount((c) => c + 1);
      },
      showTyping ? TYPING_DELAY : STEP_DELAY
    );

    return () => {
      if (startTypingTimer !== undefined) window.clearTimeout(startTypingTimer);
      window.clearTimeout(revealTimer);
    };
  }, [visibleCount]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [visibleCount, typing]);

  const done = visibleCount >= SCRIPT.length;

  return (
    <div className="flex h-full flex-col bg-whatsapp-bg">
      <div className="safe-top flex shrink-0 items-center justify-between bg-white px-5 py-3">
        <div className="flex items-center gap-2.5">
          <button onClick={onBack} className="mr-1 text-[#111]/40">
            <span className="sr-only">Voltar</span>‹
          </button>
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#e4e4e4]">
            <User className="h-4 w-4 text-[#999]" />
          </span>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-[16px] font-semibold text-[#0a0a0a]">Zé Victor</span>
              <BadgeCheck className="h-3 w-3 text-brand-green" />
            </div>
            <p className="text-xs text-[#22d37e]">Online</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-brand-green">
          <Video className="h-5 w-5" strokeWidth={1.75} />
          <Phone className="h-4 w-4" strokeWidth={1.75} />
        </div>
      </div>

      <div ref={scrollRef} className="no-scrollbar flex-1 space-y-3 overflow-y-auto px-4 py-4">
        <AnimatePresence initial={false}>
          {SCRIPT.slice(0, visibleCount).map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.22 }}
              className={cn("flex", msg.from === "me" ? "justify-end" : "justify-start")}
            >
              <div
                className={cn(
                  "max-w-[75%] rounded-xl px-2.5 py-1.5 text-[15px] leading-[21px] text-[#0a0a0a] shadow-[0_1px_0_rgba(0,0,0,0.08)]",
                  msg.from === "me" ? "bg-[#d0fecf]" : "bg-white"
                )}
              >
                {msg.text.split("\n").map((line, li) => (
                  <p key={li}>{line}</p>
                ))}
                <p className="mt-0.5 text-right text-[11px] text-black/40">{msg.time}</p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {typing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="flex items-center gap-1 rounded-xl bg-white px-3 py-2.5 shadow-[0_1px_0_rgba(0,0,0,0.08)]">
              {[0, 1, 2].map((i) => (
                <motion.span
                  key={i}
                  className="h-1.5 w-1.5 rounded-full bg-[#bbb]"
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 1, repeat: Infinity, delay: i * 0.15 }}
                />
              ))}
            </div>
          </motion.div>
        )}
      </div>

      <div className="safe-bottom shrink-0 px-5 pb-6 pt-2">
        {done && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
              Acessar sistema agora
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
