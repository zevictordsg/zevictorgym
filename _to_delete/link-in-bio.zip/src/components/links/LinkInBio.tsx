"use client";

import type { ComponentType, SVGProps } from "react";
import Image from "next/image";
import { motion, type Variants } from "framer-motion";
import { ArrowRight, ArrowUpRight, FileSpreadsheet, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { DiscordIcon, InstagramIcon, TikTokIcon } from "./icons";

/**
 * Página de links pessoal ("link-in-bio") — fica na raiz do site (`/`), com
 * o funil da planilha movido pra `/planilhadohack`. Fundo praticamente
 * preto (`#050505`) porque o recorte em `public/images/link.webp` já é
 * puro preto com alfa variável (confirmado via PIL: RGB 0,0,0 em toda a
 * borda esfumaçada) — colado sobre esse tom específico, a transição do
 * retrato pro fundo da página fica costurada sem nenhuma borda visível.
 *
 * Estética inspirada nas referências "Blank School" que o usuário enviou:
 * paleta quase monocromática, tipografia serifada itálica pontual (reusa
 * `font-script`/Instrument Serif já carregada pro logo do Carbmaxxing) e
 * cartões escuros com hairline — aqui adaptado pra botões de link com um
 * toque de cor por plataforma nos badges de ícone.
 */

type LinkItem = {
  key: string;
  href: string;
  label: string;
  subtitle: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  color: string;
  external: boolean;
  primary?: boolean;
};

const LINKS: LinkItem[] = [
  {
    key: "planilha",
    href: "/planilhadohack",
    label: "Planilha do Hack",
    subtitle: "Acesse gratuitamente",
    icon: FileSpreadsheet,
    color: "#34c16d",
    external: false,
    primary: true,
  },
  {
    key: "discord",
    href: "https://discord.gg/ryMeXhjW",
    label: "Comunidade no Discord",
    subtitle: "Converse com quem já aplica",
    icon: DiscordIcon,
    color: "#5865f2",
    external: true,
  },
  {
    key: "auralab",
    href: "https://apps.apple.com/br/app/auralab/id6794130003",
    label: "App AuraLab",
    subtitle: "Baixe na App Store",
    icon: Sparkles,
    color: "#a78bfa",
    external: true,
  },
  {
    key: "instagram",
    href: "https://www.instagram.com/zevictor.gym/",
    label: "Instagram",
    subtitle: "@zevictor.gym",
    icon: InstagramIcon,
    color: "#e1306c",
    external: true,
  },
  {
    key: "tiktok",
    href: "https://www.tiktok.com/@zevictor.gym",
    label: "TikTok",
    subtitle: "@zevictor.gym",
    icon: TikTokIcon,
    color: "#25f4ee",
    external: true,
  },
];

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.2 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] } },
};

function LinkRow({ data, index }: { data: LinkItem; index: number }) {
  const Icon = data.icon;
  const ArrowIcon = data.external ? ArrowUpRight : ArrowRight;

  return (
    <motion.a
      href={data.href}
      target={data.external ? "_blank" : undefined}
      rel={data.external ? "noopener noreferrer" : undefined}
      variants={item}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
      className={cn(
        "group relative flex w-full items-center gap-3.5 overflow-hidden rounded-[18px] border px-4 py-3.5 transition-colors duration-200",
        data.primary
          ? "border-[#34c16d]/40 bg-[#34c16d]/[0.08] shadow-[0_10px_30px_rgba(52,193,109,0.16)]"
          : "border-white/[0.08] bg-white/[0.03] hover:border-white/[0.15] hover:bg-white/[0.055]"
      )}
    >
      {/* brilho passageiro — varre o card de tempos em tempos pra puxar o
          olho do lead sem depender de interação, atraso escalonado por
          índice pra não disparar tudo junto */}
      <motion.span
        aria-hidden
        className="pointer-events-none absolute inset-y-0 left-0 w-1/3 -skew-x-12 bg-gradient-to-r from-transparent via-white/[0.08] to-transparent"
        initial={{ x: "-120%" }}
        animate={{ x: "420%" }}
        transition={{
          duration: 1.6,
          delay: 1.4 + index * 0.45,
          repeat: Infinity,
          repeatDelay: 5.5,
          ease: "easeInOut",
        }}
      />

      {data.primary && (
        <motion.span
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-[18px]"
          style={{ boxShadow: "0 0 0 1px rgba(52,193,109,0.35)" }}
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      <span
        className="relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-[13px]"
        style={{ background: `${data.color}20`, color: data.color }}
      >
        <Icon className="h-5 w-5" />
      </span>

      <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start text-left">
        <span className="text-[15px] font-semibold tracking-[-0.2px] text-white">
          {data.label}
        </span>
        <span className="text-[12px] text-white/40">{data.subtitle}</span>
      </span>

      <ArrowIcon className="relative z-10 h-4 w-4 shrink-0 text-white/30 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-white/80" />
    </motion.a>
  );
}

export function LinkInBio() {
  return (
    <div className="relative min-h-dvh w-full overflow-hidden bg-[#050505]">
      {/* glows ambiente atrás do retrato — respiração lenta e infinita,
          bem sutil, só pra dar profundidade ao fundo quase preto */}
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -top-16 left-1/2 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-[#34c16d]/[0.16] blur-[110px]"
        animate={{ opacity: [0.5, 0.9, 0.5], scale: [1, 1.08, 1] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden
        className="pointer-events-none absolute right-[-90px] top-52 h-[300px] w-[300px] rounded-full bg-[#7c5cfc]/[0.13] blur-[100px]"
        animate={{ opacity: [0.35, 0.7, 0.35], scale: [1, 1.12, 1] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut", delay: 1.4 }}
      />

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col items-center px-6 pb-[calc(env(safe-area-inset-bottom)+40px)] pt-[calc(env(safe-area-inset-top)+36px)]"
      >
        <motion.div
          variants={item}
          animate={{ y: [0, -8, 0] }}
          transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut" }}
          className="relative aspect-[1108/1235] w-[74vw] max-w-[300px]"
        >
          <Image
            src="/images/link.webp"
            alt="Zé Victor"
            fill
            priority
            sizes="300px"
            className="object-contain"
          />
        </motion.div>

        <motion.div variants={item} className="-mt-2 flex flex-col items-center gap-2.5 text-center">
          <p className="text-[19px] font-semibold tracking-[-0.3px] text-white">
            @zevictor.gym
          </p>
          <p className="max-w-[280px] font-script text-[17px] italic leading-[1.4] text-white/50">
            &ldquo;Hackeando a fisiologia a favor da estética&rdquo;
          </p>
        </motion.div>

        <div className="mt-9 flex w-full flex-col gap-3">
          {LINKS.map((l, i) => (
            <LinkRow key={l.key} data={l} index={i} />
          ))}
        </div>

        <motion.p
          variants={item}
          className="mt-10 text-[10px] uppercase tracking-[1.5px] text-white/20"
        >
          Zé Victor © 2026
        </motion.p>
      </motion.div>
    </div>
  );
}
