"use client";

import Image from "next/image";
import { motion, type Variants } from "framer-motion";
import { SocialProofPill, Callout } from "@/components/ui/Card";
import { Logo } from "@/components/ui/Logo";
import { SwipeButton } from "@/components/ui/SwipeButton";
import type { FunnelScreenProps } from "../types";

const container: Variants = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.09, delayChildren: 0.05 },
  },
};

const item: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] },
  },
};

export function Screen01Hook({ onNext }: FunnelScreenProps) {
  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="flex min-h-full w-full flex-col items-center gap-7 px-5 pb-8 pt-1"
    >
      <motion.div variants={item}>
        <Logo />
      </motion.div>

      <motion.div variants={item}>
        <SocialProofPill>
          Pessoas acessando a planilha <span className="text-foreground">+29</span>
        </SocialProofPill>
      </motion.div>

      <motion.div variants={item} className="flex justify-center gap-1">
        <div className="relative h-[172px] w-[124px] overflow-hidden rounded-[13px] bg-[#eee]">
          <Image
            src="/images/esquerda.webp"
            alt="Antes de aplicar o hack"
            fill
            sizes="124px"
            className="object-cover"
            priority
          />
        </div>
        <div className="relative h-[172px] w-[124px] overflow-hidden rounded-[13px] bg-[#eee]">
          <Image
            src="/images/direita.webp"
            alt="Depois de aplicar o hack"
            fill
            sizes="124px"
            className="object-cover"
            priority
          />
        </div>
      </motion.div>

      <motion.div variants={item} className="flex flex-col items-center gap-3 text-center">
        <h1 className="text-[28px] font-semibold leading-[1.1] tracking-tight text-foreground-strong">
          Vou te entregar o hack de macros que me fez atingir 10% de gordura
          corporal enquanto aumentei em até{" "}
          <span className="text-brand-green">1000 calorias a minha dieta!</span>
        </h1>

        <p className="text-[16px] leading-[1.4] text-foreground/50">
          Colegas que testaram essa técnica atingiram percentuais até mais
          baixos que o meu,{" "}
          <span className="font-bold text-foreground/50">
            mesmo com 2 ou 3 refeições livres na semana.
          </span>
        </p>
      </motion.div>

      <motion.div variants={item} className="w-full">
        <Callout tone="danger" className="font-semibold opacity-50">
          Aqui você vai ter acesso à estrutura de dieta que eu realmente testei
          na prática, não um copia do gpt.
        </Callout>
      </motion.div>

      <div className="flex-1" />

      <motion.div variants={item} className="flex w-full flex-col items-center gap-3">
        <SwipeButton label="Iniciar agora" onComplete={onNext} />

        <p className="text-[14px] text-foreground/40">Deslize pra iniciar</p>

        <div className="flex items-center gap-1">
          {[0, 1, 2].map((i) => (
            <motion.span
              key={i}
              className="flex opacity-70"
              animate={{ opacity: [0.25, 1, 0.25], x: [0, 3, 0] }}
              transition={{
                duration: 1.4,
                repeat: Infinity,
                delay: i * 0.18,
                ease: "easeInOut",
              }}
            >
              <Image src="/arrow.svg" alt="" width={7} height={11} aria-hidden />
            </motion.span>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}
