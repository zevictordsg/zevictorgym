"use client";

import { useEffect, useState } from "react";
import { Play } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/Button";
import { Wordmark } from "@/components/ui/Logo";
import { ArrowRight } from "../icons";
import type { FunnelScreenProps } from "../types";

/**
 * Tela de VSL — fiel ao node 2364:4306 do Figma: headline + placeholder de
 * vídeo (retângulo cinza arredondado) + wordmark no rodapé. O CTA não
 * existe no frame estático do Figma (que é só o mockup "idle") — ele some
 * por padrão e aparece sobreposto ao placeholder depois de alguns
 * segundos, pedido à parte pelo usuário.
 *
 * O placeholder usa `flex-1` (em vez de aspect-ratio fixo) pra ocupar
 * exatamente o espaço que sobra entre o título e o wordmark — garante que
 * a tela sempre cabe sem scroll, em qualquer altura de viewport.
 */
const videoSrc: string | null = null;
const revealCtaAfterSeconds = 5;

export function Screen02VSL({ onNext }: FunnelScreenProps) {
  const [ctaVisible, setCtaVisible] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(
      () => setCtaVisible(true),
      revealCtaAfterSeconds * 1000
    );
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="flex h-full min-h-0 flex-col items-center gap-4 bg-background px-5 pb-[calc(env(safe-area-inset-bottom)+16px)] pt-[calc(env(safe-area-inset-top)+16px)]">
      <h1 className="shrink-0 text-center text-[20px] font-semibold leading-[1.1] tracking-[-0.8px] text-[#444]">
        Assista o vídeo abaixo pra
        <br />
        receber o material completo
      </h1>

      <div className="relative min-h-0 w-full flex-1 overflow-hidden rounded-[15px] bg-[#d9d9d9]">
        {videoSrc ? (
          <video
            src={videoSrc}
            autoPlay
            muted
            playsInline
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-white/70 text-[#444]">
              <Play className="h-5 w-5 translate-x-0.5" fill="currentColor" />
            </span>
          </div>
        )}

        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center p-4">
          {ctaVisible && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
              className="pointer-events-auto w-full"
            >
              <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
                Continuar
              </Button>
            </motion.div>
          )}
        </div>
      </div>

      <Wordmark className="shrink-0" />
    </div>
  );
}
