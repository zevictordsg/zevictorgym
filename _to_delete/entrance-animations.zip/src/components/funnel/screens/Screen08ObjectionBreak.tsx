"use client";

import { Image as ImageIcon } from "lucide-react";
import { motion, type Variants } from "framer-motion";
import { Button } from "@/components/ui/Button";
import { Callout } from "@/components/ui/Card";
import { CheckItem } from "@/components/ui/CheckItem";
import { ArrowRight } from "../icons";
import type { FunnelScreenProps } from "../types";

const BULLETS = [
  "Aulas onde estruturo tudo no passo a passo",
  "Sistema que te permite liberdade na dieta",
  "Distribuição correta de macros e calorias",
  "Materiais completos de acompanhamento",
  "Aulas científicas te explicando a base de tudo",
];

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.08, delayChildren: 0.05 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease: [0.16, 1, 0.3, 1] } },
};

const bulletsContainer: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07, delayChildren: 0.1 } },
};

const bulletItem: Variants = {
  hidden: { opacity: 0, x: -10 },
  show: { opacity: 1, x: 0, transition: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } },
};

export function Screen08ObjectionBreak({ onNext }: FunnelScreenProps) {
  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="flex h-full min-h-0 flex-col justify-center gap-3 px-5 pb-4 pt-1"
    >
      <motion.div variants={item}>
        <Callout tone="amber" className="text-[13px]">
          🚨 Ainda bem que você chegou até aqui, afinal quem chega cedo bebe
          água limpa🚨
        </Callout>
      </motion.div>

      {/* Placeholder — troque pela foto real usada no Figma */}
      <motion.div
        variants={item}
        className="flex h-[104px] w-full items-center justify-center rounded-[20px] bg-gradient-to-br from-[#efe4d0] to-[#d8c9a8] shadow-[0_4px_19.9px_rgba(0,0,0,0.25)]"
      >
        <ImageIcon className="h-7 w-7 text-[#a8926a]" strokeWidth={1.5} />
      </motion.div>

      <motion.div variants={item} className="flex flex-col gap-1.5 text-center">
        <p className="text-[13px] font-bold leading-[1.35] text-foreground/50">
          Copie e cole a organização de calorias e macros que me permitem
          aproveitar refs livres sem sentir culpa e ainda transformar isso em
          combustível para meus treinos!
        </p>
        <p className="text-[12px] leading-[1.35] text-[#939393]">
          Essa estrutura me fez literalmente alcançar um físico que eu só
          imaginava ter com dietas super restritivas e que me deixariam com
          fome o dia todo.
        </p>
      </motion.div>

      <motion.div variants={bulletsContainer} className="flex flex-col gap-1.5">
        {BULLETS.map((b) => (
          <motion.div key={b} variants={bulletItem}>
            <CheckItem tone="green-soft" className="py-2 text-xs">
              {b}
            </CheckItem>
          </motion.div>
        ))}
      </motion.div>

      <motion.div variants={item}>
        <Button
          onClick={onNext}
          icon={<ArrowRight className="h-3.5 w-3.5" />}
          className="mt-1"
        >
          Quero o material mais completo!
        </Button>
      </motion.div>
    </motion.div>
  );
}
