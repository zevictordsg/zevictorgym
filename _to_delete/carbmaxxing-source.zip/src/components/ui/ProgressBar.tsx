"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

export function ProgressBar({
  value,
  tone = "light",
  className,
}: {
  /** 0 a 1 */
  value: number;
  /** "light" = trilho cinza claro (telas brancas) · "dark" = trilho translúcido (telas escuras) */
  tone?: "light" | "dark";
  className?: string;
}) {
  return (
    <div
      className={className}
      role="progressbar"
      aria-valuenow={Math.round(value * 100)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={cn(
          "h-1.5 w-full overflow-hidden rounded-full",
          tone === "light" ? "bg-[#eeeeee]" : "bg-white/15"
        )}
      >
        <motion.div
          className="h-full rounded-full bg-brand-green"
          initial={false}
          animate={{ width: `${Math.min(Math.max(value, 0), 1) * 100}%` }}
          transition={{ type: "spring", stiffness: 260, damping: 30 }}
        />
      </div>
    </div>
  );
}
