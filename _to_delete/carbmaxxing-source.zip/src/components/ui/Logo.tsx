import { cn } from "@/lib/utils";

/**
 * Marca "C." — no Figma é um vetor desenhado à mão (SVG).
 * Aproximamos com itálico serifado; troque pelo SVG exportado do
 * Figma quando quiser fidelidade exata (Assets > "C." > Export).
 */
export function Logo({ className }: { className?: string }) {
  return (
    <span className={cn("font-[var(--font-script)] text-3xl italic", className)}>
      C.
    </span>
  );
}

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={cn("inline-flex flex-col items-center gap-0.5", className)}>
      <span className="text-[18px] font-bold tracking-[-0.4px] text-[#cbcbcb]">
        Carbmaxxing<sup className="text-[11px] font-bold">®</sup>
      </span>
      <span className="text-[8px] font-bold tracking-[-0.3px] text-[#cbcbcb] opacity-60">
        by zevictor.gym
      </span>
    </span>
  );
}
