"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useTransform, animate } from "framer-motion";
import Image from "next/image";
import { cn } from "@/lib/utils";

const HANDLE_SIZE = 44; // px — h-11 w-11
const TRACK_PADDING = 6; // px — p-1.5
const COMPLETE_THRESHOLD = 0.62; // % da trilha arrastada pra confirmar

/**
 * Botão "deslize para iniciar" — arrasta o círculo até o fim da trilha
 * pra disparar `onComplete`. Um clique simples NÃO avança: é proposital,
 * pra reforçar a interação gamificada pedida pro hook do funil.
 */
export function SwipeButton({
  label,
  onComplete,
  className,
}: {
  label: string;
  onComplete: () => void;
  className?: string;
}) {
  const trackRef = useRef<HTMLDivElement>(null);
  const [maxDrag, setMaxDrag] = useState(0);
  const [done, setDone] = useState(false);
  const x = useMotionValue(0);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;

    function measure(width: number) {
      setMaxDrag(Math.max(width - HANDLE_SIZE - TRACK_PADDING * 2, 0));
    }
    measure(el.offsetWidth);

    const ro = new ResizeObserver((entries) => {
      const width = entries[0]?.contentRect.width;
      if (width) measure(width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const safeMax = Math.max(maxDrag, 1);
  const fillOpacity = useTransform(x, [0, safeMax], [0, 1]);
  const labelOpacity = useTransform(x, [0, safeMax * 0.55], [1, 0]);
  const hintOpacity = useTransform(x, [0, safeMax * 0.3], [1, 0]);

  function handleDragEnd() {
    if (done) return;
    const progress = maxDrag > 0 ? x.get() / maxDrag : 0;

    if (progress > COMPLETE_THRESHOLD) {
      animate(x, maxDrag, {
        type: "spring",
        stiffness: 340,
        damping: 32,
        onComplete: () => {
          setDone(true);
          window.setTimeout(onComplete, 260);
        },
      });
    } else {
      animate(x, 0, { type: "spring", stiffness: 420, damping: 34 });
    }
  }

  return (
    <div
      ref={trackRef}
      className={cn(
        "relative flex w-full items-center overflow-hidden rounded-[24px] border border-[#f0f0f0] bg-[#e8e8e8] p-1.5",
        className
      )}
    >
      <motion.div
        aria-hidden
        className="cta-gradient absolute inset-1.5 rounded-[16px]"
        style={{ opacity: fillOpacity }}
      />

      <motion.span
        aria-hidden
        className="pointer-events-none absolute inset-0 flex items-center justify-center text-[16px] font-bold text-foreground/50"
        style={{ opacity: labelOpacity }}
      >
        {label}
      </motion.span>

      <motion.div
        role="button"
        tabIndex={0}
        aria-label={label}
        drag={done ? false : "x"}
        dragConstraints={{ left: 0, right: maxDrag }}
        dragElastic={0.04}
        dragMomentum={false}
        style={{ x }}
        onDragEnd={handleDragEnd}
        onKeyDown={(e) => {
          if ((e.key === "Enter" || e.key === " ") && !done) {
            e.preventDefault();
            animate(x, maxDrag, {
              type: "spring",
              stiffness: 340,
              damping: 32,
              onComplete: () => {
                setDone(true);
                window.setTimeout(onComplete, 260);
              },
            });
          }
        }}
        whileTap={{ scale: 0.96 }}
        className="relative z-10 flex h-11 w-11 shrink-0 cursor-grab items-center justify-center rounded-xl bg-white text-foreground/50 shadow-[4px_7px_6.55px_rgba(0,0,0,0.12)] active:cursor-grabbing"
      >
        <motion.span style={{ opacity: hintOpacity }} className="flex">
          <Image src="/arrow.svg" alt="" width={7} height={11} aria-hidden />
        </motion.span>
      </motion.div>
    </div>
  );
}
