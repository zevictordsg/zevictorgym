"use client";

import { User } from "lucide-react";
import { SocialProofPill, Callout } from "@/components/ui/Card";
import type { FunnelScreenProps } from "../types";

export function Screen01Hook({ onNext }: FunnelScreenProps) {
  return (
    <div className="flex min-h-full flex-col items-center gap-7 px-5 pb-8 pt-1">
      <SocialProofPill>
        Pessoas acessando a planilha <span className="text-foreground">+29</span>
      </SocialProofPill>

      {/* Placeholder para as fotos antes/depois — troque pelas fotos reais do usuário */}
      <div className="flex justify-center gap-1">
        <div className="flex h-[172px] w-[124px] items-center justify-center rounded-[13px] bg-gradient-to-b from-[#f2f2f2] to-[#e2e2e2]">
          <User className="h-8 w-8 text-[#bbb]" strokeWidth={1.5} />
        </div>
        <div className="flex h-[172px] w-[124px] items-center justify-center rounded-[13px] bg-gradient-to-b from-[#eafff3] to-[#d7f5e4]">
          <User className="h-8 w-8 text-brand-green" strokeWidth={1.5} />
        </div>
      </div>

      <div className="flex flex-col items-center gap-3 text-center">
        <h1 className="text-[28px] font-semibold leading-[1.1] tracking-tight text-foreground-strong">
          Vou te entregar o hack de macros que me fez atingir 10% de gordura
          corporal enquanto aumentei em até{" "}
          <span className="text-brand-green">1000 calorias a minha dieta!</span>
        </h1>

        <p className="text-[16px] leading-[1.4] text-foreground/50">
          Colegas que testaram essa técnica atingiram percentuais até mais
          baixos que o meu,{" "}
          <span className="font-bold text-foreground/50">
            mesmo com 2 ou 3 refeições livres na semana.
          </span>
        </p>
      </div>

      <Callout tone="danger" className="font-semibold opacity-50">
        Aqui você vai ter acesso à estrutura de dieta que eu realmente testei
        na prática, não um copia do gpt.
      </Callout>

      <div className="flex-1" />

      <div className="flex w-full flex-col items-center gap-3">
        <button
          onClick={onNext}
          className="flex w-full items-center rounded-[24px] border border-[#f0f0f0] bg-[#e8e8e8] p-1.5"
        >
          <span className="flex flex-1 items-center justify-center gap-2.5 rounded-[16px] bg-white py-3 pl-5 pr-1.5 shadow-[4px_7px_6.55px_rgba(0,0,0,0.12)]">
            <span className="text-[16px] font-bold text-foreground/50">
              Iniciar agora
            </span>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#f3f3f5] text-[16px] text-foreground/50">
              →
            </span>
          </span>
        </button>

        <p className="text-[14px] text-foreground/40">Deslize pra iniciar</p>
        <div className="flex gap-1.5">
          {[0, 1, 2].map((i) => (
            <span key={i} className="h-2 w-1.5 rounded-full bg-[#d9d9d9]" />
          ))}
        </div>
      </div>
    </div>
  );
}
