import type { ComponentType } from "react";
import { Screen01Hook } from "@/components/funnel/screens/Screen01Hook";
import { Screen02VSL } from "@/components/funnel/screens/Screen02VSL";
import { Screen03CalorieReveal } from "@/components/funnel/screens/Screen03CalorieReveal";
import { Screen04Placeholder } from "@/components/funnel/screens/Screen04Placeholder";
import { Screen05WhatsApp } from "@/components/funnel/screens/Screen05WhatsApp";
import { Screen06ComparisonScroll } from "@/components/funnel/screens/Screen06ComparisonScroll";
import { Screen07VoucherSpin } from "@/components/funnel/screens/Screen07VoucherSpin";
import { Screen08ObjectionBreak } from "@/components/funnel/screens/Screen08ObjectionBreak";
import { Screen09Placeholder } from "@/components/funnel/screens/Screen09Placeholder";
import type { FunnelScreenProps } from "@/components/funnel/types";

export type FunnelStep = {
  id: string;
  Component: ComponentType<FunnelScreenProps>;
  /** esconde o header padrão (voltar + progresso) — tela cuida do próprio chrome */
  bare?: boolean;
  /** cor dos ícones do header quando `bare` é false */
  theme?: "light" | "dark";
};

/**
 * Registro central do funil, sincronizado com o arquivo Figma
 * (node-ids conferidos via MCP em 2026-08-25):
 *
 *  1. hook                 — node 2364:4236  ✅ implementada
 *  2. vsl                  — node 2364:4306  ✅ implementada (vídeo placeholder)
 *  3. calorie-reveal        — node 2364:4335  ✅ implementada
 *  4. model-comparison      — ⚠️ SEM LINK CONFIRMADO (o link enviado como "quarta
 *     tela" apontava pro mesmo node da tela 3). Preciso do node-id certo da tela
 *     de comparação "Cutting agressivo / Carbmaxxing hack / Bulking".
 *  5. whatsapp              — node 2373:2     ✅ implementada
 *  6. comparison-scroll     — node 2373:1472  ✅ implementada
 *  7. voucher               — node 2374:1638  ✅ implementada
 *  8. objection-break       — node 2375:1746  ✅ implementada
 *  9. final-offer           — ⚠️ SEM LINK CONFIRMADO (o link enviado como "nona
 *     tela" apontava pro mesmo node da tela 8, repetido). Preciso do node-id
 *     certo da oferta final (planilha grátis vs Carbmaxxing ELITE + Stripe).
 */
export const FUNNEL_STEPS: FunnelStep[] = [
  { id: "hook", Component: Screen01Hook, theme: "light" },
  { id: "vsl", Component: Screen02VSL, bare: true },
  { id: "calorie-reveal", Component: Screen03CalorieReveal, theme: "light" },
  { id: "model-comparison", Component: Screen04Placeholder, theme: "light" },
  { id: "whatsapp", Component: Screen05WhatsApp, bare: true },
  { id: "comparison-scroll", Component: Screen06ComparisonScroll, theme: "light" },
  { id: "voucher", Component: Screen07VoucherSpin, bare: true },
  { id: "objection-break", Component: Screen08ObjectionBreak, theme: "light" },
  { id: "final-offer", Component: Screen09Placeholder, theme: "light" },
];
