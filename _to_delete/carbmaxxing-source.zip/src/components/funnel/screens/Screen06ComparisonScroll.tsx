"use client";

import { Check, User, X } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { BadgeCard } from "@/components/ui/Card";
import { ArrowRight } from "../icons";
import { cn } from "@/lib/utils";
import type { FunnelScreenProps } from "../types";

const BENEFITS = [
  "Treinos com muito mais energia",
  "Direcionamento correto do Carboidrato",
  "Aspecto de ”Seco” mesmo comendo ”besteiras”",
  "Ganho de músculo enquanto perde gordura",
  "Adesão à dieta que realmente te faz crescer",
  "A cada refeição seus músculos agradecem",
];

function ChecklistRow({
  children,
  positive,
}: {
  children: string;
  positive: boolean;
}) {
  const Icon = positive ? Check : X;
  return (
    <div
      className="flex w-full items-center gap-1.5 text-xs font-medium"
      style={{ color: positive ? "var(--check-green-text)" : "var(--check-red-text)" }}
    >
      <Icon className="h-3 w-3 shrink-0" strokeWidth={2.5} />
      <span>{children}</span>
    </div>
  );
}

export function Screen06ComparisonScroll({ onNext }: FunnelScreenProps) {
  return (
    <div className="flex min-h-full flex-col gap-8 px-5 pb-8 pt-1">
      <p className="text-center text-[18px] leading-[1.4] text-foreground/50">
        A partir de agora a decisão é óbvia... E seu único objetivo é não
        deixar sua preguiça tomar conta (eu quase deixei) 👇
      </p>

      <div className="flex flex-col gap-4">
        <div
          className="flex flex-col gap-4 rounded-[15px] border-2 px-[15px] py-3"
          style={{ background: "var(--check-green-bg)", borderColor: "var(--check-green-border)" }}
        >
          <div className="flex items-center gap-2.5">
            <Check className="h-4 w-4" style={{ color: "var(--check-green-title)" }} strokeWidth={2.5} />
            <p className="text-[16px] font-bold tracking-tight" style={{ color: "var(--check-green-title)" }}>
              APLICANDO O CARBMAXXING
            </p>
          </div>
          <div className="flex flex-col gap-3">
            {BENEFITS.map((b) => (
              <ChecklistRow key={b} positive>
                {b}
              </ChecklistRow>
            ))}
          </div>
        </div>

        <div
          className="flex flex-col gap-4 rounded-[15px] border-2 px-[15px] py-3"
          style={{ background: "var(--check-red-bg)", borderColor: "var(--check-red-border)" }}
        >
          <div className="flex items-center gap-2.5">
            <X className="h-4 w-4" style={{ color: "var(--check-red-title)" }} strokeWidth={2.5} />
            <p className="text-[16px] font-bold tracking-tight" style={{ color: "var(--check-red-title)" }}>
              SEM APLICAR O CARBMAXXING
            </p>
          </div>
          <div className="flex flex-col gap-3">
            {BENEFITS.map((b) => (
              <ChecklistRow key={b} positive={false}>
                {b}
              </ChecklistRow>
            ))}
          </div>
        </div>
      </div>

      <div
        className="flex flex-col gap-3.5 rounded-[15px] border-2 px-[15px] py-3"
        style={{ background: "rgba(255,252,235,0.2)", borderColor: "rgba(202,202,202,0.3)" }}
      >
        <span className="w-fit rounded-[5px] bg-[#414141] px-2 py-1 text-[10px] font-bold text-white">
          PARECE LOUCURA NÉ
        </span>
        <p className="text-[18px] font-semibold leading-[1.3] text-[#4f4f4f]">
          Com poucos ajustes sua dieta ajusta seu metabolismo da forma correta
          e trabalha a favor do seu shape.
        </p>
        {/* Placeholder — troque pelas fotos reais de antes/depois */}
        <div className="flex w-full justify-between gap-2">
          <div className={cn("flex h-[130px] flex-1 items-center justify-center rounded-2xl", "bg-gradient-to-b from-[#f2f2f2] to-[#e2e2e2]")}>
            <User className="h-7 w-7 text-[#bbb]" strokeWidth={1.5} />
          </div>
          <div className={cn("flex h-[130px] flex-1 items-center justify-center rounded-2xl", "bg-gradient-to-b from-[#eafff3] to-[#d7f5e4]")}>
            <User className="h-7 w-7 text-brand-green" strokeWidth={1.5} />
          </div>
        </div>
        <p className="text-[14px] leading-[1.4] text-[#939393]">
          Eu comia literalmente 500 calorias a menos na primeira imagem e hoje
          tenho muito mais liberdade com um físico muito mais estético e seco
        </p>
      </div>

      <BadgeCard
        badge="OPORTUNIDADE DE PRIMEIRO ACESSO"
        badgeBg="#dfa228"
        bg="rgba(255,245,178,0.2)"
        border="rgba(236,213,120,0.3)"
        className="gap-2.5"
      >
        <p className="text-[18px] font-semibold leading-[1.3]" style={{ color: "var(--callout-amber-text)" }}>
          Você recebeu um voucher premiado por ter sido 1 dos 50 primeiros que
          chegaram até aqui e não vai sair apenas com uma planilha de dieta 🫡
        </p>
        <p className="text-[14px] leading-[1.4] text-[#6c6c6c]">
          Clique no botão abaixo para ir garantir seu acesso a uma
          oportunidade única que vai receber{" "}
          <span className="font-bold">ALÉM DO MATERIAL GRATUITO</span>
        </p>
      </BadgeCard>

      <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
        Quero entender mais
      </Button>
    </div>
  );
}
