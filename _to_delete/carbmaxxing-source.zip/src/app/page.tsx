import { FunnelEngine } from "@/components/funnel/FunnelEngine";

export default function Home() {
  return (
    <main className="flex min-h-dvh w-full items-center justify-center bg-[#0b0b0c] sm:p-6">
      <div className="relative h-dvh w-full overflow-hidden bg-background sm:h-[880px] sm:max-h-[92dvh] sm:w-[430px] sm:rounded-[2.5rem] sm:border sm:border-white/10 sm:shadow-2xl">
        <FunnelEngine />
      </div>
    </main>
  );
}
