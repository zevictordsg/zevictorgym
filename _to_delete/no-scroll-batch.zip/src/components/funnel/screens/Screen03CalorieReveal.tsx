"use client";

import { motion } from "framer-motion";
import { Pizza, IceCreamCone, Cookie } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { CheckItem } from "@/components/ui/CheckItem";
import { CountUp } from "@/components/ui/CountUp";
import { ArrowRight } from "../icons";
import type { FunnelScreenProps } from "../types";

const foodIcons = [Pizza, IceCreamCone, Cookie];

export function Screen03CalorieReveal({ onNext }: FunnelScreenProps) {
  return (
    <div className="flex h-full min-h-0 flex-col items-center justify-center gap-4 px-5 pb-4 pt-1">
      <div className="relative">
        <span
          className="absolute left-1/2 top-0 z-10 -translate-x-1/2 -translate-y-3 text-[22px]"
          style={{ transform: "translate(-50%, -70%) rotate(4.25deg)" }}
        >
          💀
        </span>

        <div className="flex flex-col items-center gap-1 rounded-[24px] bg-dark-card-bg px-3 py-4 shadow-[0_8px_18px_rgba(0,0,0,0.3)]">
          <p className="text-[10px] font-medium uppercase tracking-[1px] text-white">
            Calorias disponíveis com o hack
          </p>
          <p className="text-[36px] font-semibold tracking-[-1.1px] text-brand-green-deep">
            +<CountUp to={1642} />
            <span className="ml-1">Calorias</span>
          </p>
          <span className="mt-1 inline-flex items-center gap-2 rounded-xl bg-[#3a3a3a] px-4 py-0.5 text-sm font-medium text-white">
            <span className="h-[5px] w-[5px] rounded-full bg-white" />
            245 kcal <span>23%</span>
          </span>
        </div>
      </div>

      {/* Placeholder — troque pelas fotos/refeições reais usadas no Figma */}
      <div className="flex justify-center gap-2.5">
        {foodIcons.map((Icon, i) => (
          <span
            key={i}
            className="flex h-[56px] w-[56px] items-center justify-center rounded-full bg-[#f3f3f5] text-foreground"
          >
            <Icon className="h-5 w-5" strokeWidth={1.5} />
          </span>
        ))}
      </div>

      <div className="flex flex-col items-center gap-2 text-center">
        <h2 className="text-[21px] font-semibold leading-[1.15] tracking-tight text-foreground-strong">
          Aplicando o &ldquo;hack&rdquo; você terá mais{" "}
          <span className="text-brand-green-deep">1000 kcal</span> diárias de
          forma direcionada
        </h2>
        <p className="text-[14px] leading-[1.35] text-foreground/50">
          Um único ajuste que direciona o &ldquo;lixo&rdquo; em combustível
          para cada treino ser insano!
        </p>
      </div>

      <div className="flex w-full flex-col gap-2">
        <CheckItem tone="red-soft">Sem passar fome</CheckItem>
        <CheckItem tone="red-soft">Sem ter medo de comer o que quer</CheckItem>
        <CheckItem tone="red-soft">Sem descontrole alimentar</CheckItem>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="w-full pt-1"
      >
        <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
          Quero aplicar o hack
        </Button>
      </motion.div>
    </div>
  );
}
