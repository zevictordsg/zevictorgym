"use client";

import { useState } from "react";
import { AnimatePresence, motion, type Variants } from "framer-motion";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Logo } from "@/components/ui/Logo";
import type { FunnelScreenProps } from "../types";

const STARS = [
  { top: "9%", left: "12%", size: 14, rotate: -15 },
  { top: "8%", right: "14%", size: 10, rotate: 20 },
  { bottom: "10%", left: "5%", size: 10, rotate: 10 },
  { bottom: "12%", right: "9%", size: 16, rotate: -8 },
];

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] } },
};

const BARCODE_WIDTHS = [3, 1, 2, 1, 3, 2, 1, 1, 3, 2, 1, 3, 2, 1, 2, 3, 1, 2];

export function Screen07VoucherSpin({ onNext }: FunnelScreenProps) {
  const [entranceRevealed, setEntranceRevealed] = useState(false);
  const [redeemed, setRedeemed] = useState(false);

  function handleRedeem() {
    if (redeemed) {
      onNext();
      return;
    }
    setRedeemed(true);
  }

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="relative flex h-full flex-col items-center justify-between overflow-hidden px-5 pb-8 pt-1"
    >
      {STARS.map((s, i) => {
        const { size, rotate, ...position } = s;
        return (
          <motion.span
            key={i}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 + i * 0.08, duration: 0.4, ease: "backOut" }}
            className="absolute"
            style={position}
          >
            <Star
              className="text-white/20"
              style={{ width: size, height: size, transform: `rotate(${rotate}deg)` }}
              fill="currentColor"
            />
          </motion.span>
        );
      })}

      <motion.div variants={item} className="flex flex-col items-center gap-6">
        <div className="relative flex items-center gap-2">
          <span className="-mt-1 -rotate-[14deg] text-2xl">🎁</span>
          <div className="text-center text-[28px] font-semibold leading-[1.1] text-[#e7e7e7]">
            <p>Resgate</p>
            <p>Seu Voucher</p>
          </div>
          <span className="-mt-1 rotate-[14deg] text-2xl">🎁</span>
        </div>

        <p className="max-w-[330px] text-center text-[18px] leading-[1.4] text-[#d4d4d4]/80">
          <span className="font-bold">Restam apenas 39 Vouchers</span> até 50
          membros. Clique em Resgatar Agora.
        </p>
      </motion.div>

      <div style={{ perspective: 1200 }}>
        <motion.button
          type="button"
          onClick={() => setEntranceRevealed(true)}
          initial={{ rotateY: 180, scale: 0.85, opacity: 0 }}
          animate={{ rotateY: 0, scale: 1, opacity: 1 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
          onAnimationComplete={() => setEntranceRevealed(true)}
          style={{ transformStyle: "preserve-3d" }}
          className="relative aspect-[283/388] w-[240px] overflow-hidden rounded-[24px] border-4 border-[#3a3a3a] bg-gradient-to-b from-[#e9e9e9] to-[#c9c9c9] shadow-[0_20px_40px_rgba(0,0,0,0.5)]"
        >
          <span className="absolute -left-2.5 top-[243px] z-10 h-5 w-5 rounded-full bg-dark-screen-bg" />
          <span className="absolute -right-2.5 top-[243px] z-10 h-5 w-5 rounded-full bg-dark-screen-bg" />

          <AnimatePresence mode="wait">
            {!redeemed ? (
              <motion.div
                key="ticket"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.25 }}
                className="absolute inset-0 flex flex-col items-center pt-[36px]"
              >
                <Logo className="text-[118px] text-[#2f2f2f]" />
                <p className="mt-3 text-center text-[20px] font-semibold leading-[1.1] text-[#2f2f2f]">
                  Resgate
                  <br />
                  Seu Voucher
                </p>

                <div className="mb-[28px] mt-auto flex h-12 items-end gap-[2px]">
                  {BARCODE_WIDTHS.map((w, i) => (
                    <span key={i} className="h-8 bg-[#2f2f2f]" style={{ width: w }} />
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="discount"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
                className="absolute inset-0 flex flex-col items-center justify-center gap-1.5"
              >
                <span className="text-[13px] font-bold uppercase tracking-[1.5px] text-brand-green">
                  Voucher liberado 🎉
                </span>
                <p className="text-[64px] font-bold leading-none tracking-tight text-[#2f2f2f]">
                  85%
                </p>
                <p className="text-[18px] font-semibold text-[#2f2f2f]">de desconto</p>
              </motion.div>
            )}
          </AnimatePresence>

          {redeemed && (
            <motion.span
              key="shine"
              initial={{ x: "-130%" }}
              animate={{ x: "130%" }}
              transition={{ duration: 0.9, ease: "easeInOut", delay: 0.2 }}
              className="pointer-events-none absolute inset-y-0 left-0 z-20 w-1/2 -skew-x-12"
              style={{
                background:
                  "linear-gradient(115deg, transparent 30%, rgba(255,255,255,0.8) 50%, transparent 70%)",
                mixBlendMode: "overlay",
              }}
            />
          )}
        </motion.button>
      </div>

      <div className="min-h-[68px] w-full">
        {entranceRevealed && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <Button variant="light" onClick={handleRedeem}>
              {redeemed ? "Continuar" : "Resgatar Agora"}
            </Button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
