"use client";

import { useState } from "react";
import { Play } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/Button";
import { Wordmark, Logo } from "@/components/ui/Logo";
import { ArrowRight } from "../icons";
import type { FunnelScreenProps } from "../types";

/**
 * Tela de VSL — no Figma é só o rótulo "VSL" centralizado (placeholder
 * de vídeo). Troque `videoSrc` pela URL final (Mux, Bunny, Cloudflare
 * Stream, ou um <video> com mp4) quando tiver o vídeo pronto.
 */
const videoSrc: string | null = null;
const revealCtaAfterSeconds = 3;

export function Screen02VSL({ onNext }: FunnelScreenProps) {
  const [ctaVisible, setCtaVisible] = useState(false);

  function handlePlay() {
    window.setTimeout(() => setCtaVisible(true), revealCtaAfterSeconds * 1000);
  }

  return (
    <div className="flex min-h-full flex-col items-center justify-between px-5 pb-8 pt-1">
      <Logo />

      <div className="flex flex-1 items-center justify-center">
        {videoSrc ? (
          <video
            src={videoSrc}
            controls
            playsInline
            className="w-full rounded-2xl object-cover"
          />
        ) : (
          <button
            onClick={handlePlay}
            className="flex flex-col items-center gap-5"
          >
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-[#f3f3f5] text-[#111]">
              <Play className="h-5 w-5 translate-x-0.5" fill="currentColor" />
            </span>
            <span className="text-[28px] font-semibold tracking-tight text-[#111]">
              VSL
            </span>
          </button>
        )}
      </div>

      <Wordmark className="mb-2" />

      <div className="min-h-[68px] w-full">
        {ctaVisible ? (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
              Continuar
            </Button>
          </motion.div>
        ) : null}
      </div>
    </div>
  );
}
