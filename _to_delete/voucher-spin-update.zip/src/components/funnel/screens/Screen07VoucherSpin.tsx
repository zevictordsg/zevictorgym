"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, type Variants } from "framer-motion";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Logo } from "@/components/ui/Logo";
import type { FunnelScreenProps } from "../types";

const STARS = [
  { top: "9%", left: "12%", size: 14, rotate: -15 },
  { top: "8%", right: "14%", size: 10, rotate: 20 },
  { bottom: "10%", left: "5%", size: 10, rotate: 10 },
  { bottom: "12%", right: "9%", size: 16, rotate: -8 },
];

const container: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.1, delayChildren: 0.05 } },
};

const item: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] } },
};

const BARCODE_WIDTHS = [3, 1, 2, 1, 3, 2, 1, 1, 3, 2, 1, 3, 2, 1, 2, 3, 1, 2];

// card2.svg (283x389, moldura escura ao fundo) e card1.svg (268x374, face
// clara sobreposta) são os "Subtract" exportados do Figma — o inset abaixo
// é a margem exata entre as duas formas (7.5px em ambos os eixos na escala
// nativa), convertida em % para se manter fiel em qualquer tamanho renderizado.
const CARD1_INSET = "1.928% 2.650%";

// giro completo (2.5 voltas) antes de assentar na face virada — 900° mod 360
// = 180°, ou seja, termina exatamente na face de trás (desconto).
const REDEEM_SPIN_DEG = 900;

export function Screen07VoucherSpin({ onNext }: FunnelScreenProps) {
  const [entranceRevealed, setEntranceRevealed] = useState(false);
  const [redeemed, setRedeemed] = useState(false);

  function handleRedeem() {
    if (redeemed) {
      onNext();
      return;
    }
    setRedeemed(true);
  }

  return (
    <motion.div
      variants={container}
      initial="hidden"
      animate="show"
      className="relative flex h-full flex-col items-center justify-between overflow-hidden px-5 pb-8 pt-1"
    >
      {STARS.map((s, i) => {
        const { size, rotate, ...position } = s;
        return (
          <motion.span
            key={i}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 + i * 0.08, duration: 0.4, ease: "backOut" }}
            className="absolute"
            style={position}
          >
            <Star
              className="text-white/20"
              style={{ width: size, height: size, transform: `rotate(${rotate}deg)` }}
              fill="currentColor"
            />
          </motion.span>
        );
      })}

      <motion.div variants={item} className="flex flex-col items-center gap-6">
        <div className="relative flex items-center gap-2">
          <span className="-mt-1 -rotate-[14deg] text-2xl">🎁</span>
          <div className="text-center text-[28px] font-semibold leading-[1.1] text-[#e7e7e7]">
            <p>Resgate</p>
            <p>Seu Voucher</p>
          </div>
          <span className="-mt-1 rotate-[14deg] text-2xl">🎁</span>
        </div>

        <p className="max-w-[330px] text-center text-[18px] leading-[1.4] text-[#d4d4d4]/80">
          <span className="font-bold">Restam apenas 39 Vouchers</span> até 50
          membros. Clique em Resgatar Agora.
        </p>
      </motion.div>

      <div style={{ perspective: 1200 }}>
        <motion.button
          type="button"
          onClick={() => setEntranceRevealed(true)}
          initial={{ rotateY: 180, scale: 0.85, opacity: 0 }}
          animate={{ rotateY: redeemed ? REDEEM_SPIN_DEG : 0, scale: 1, opacity: 1 }}
          transition={
            redeemed
              ? { duration: 0.95, ease: [0.45, 0, 0.2, 1] }
              : { duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.15 }
          }
          onAnimationComplete={() => setEntranceRevealed(true)}
          style={{ transformStyle: "preserve-3d" }}
          className="relative aspect-[283/389] w-[208px] shadow-[0_20px_40px_rgba(0,0,0,0.5)]"
        >
          {/* moldura escura (card2) — fica visível o giro inteiro, atrás das faces */}
          <Image src="/images/card2.svg" alt="" fill priority className="pointer-events-none select-none" />

          {/* face da frente: ticket */}
          <div
            className="absolute flex flex-col items-center pt-[22px]"
            style={{ inset: CARD1_INSET, backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden" }}
          >
            <Image src="/images/card1.svg" alt="" fill className="pointer-events-none absolute inset-0 -z-10 select-none" />
            <Logo className="text-[100px] text-[#2f2f2f]" />
            <p className="mt-2 text-center text-[17px] font-semibold leading-[1.1] text-[#2f2f2f]">
              Resgate
              <br />
              Seu Voucher
            </p>

            <div className="mb-[18px] mt-auto flex h-10 items-end gap-[2px]">
              {BARCODE_WIDTHS.map((w, i) => (
                <span key={i} className="h-7 bg-[#2f2f2f]" style={{ width: w }} />
              ))}
            </div>
          </div>

          {/* face de trás: desconto liberado */}
          <div
            className="absolute flex flex-col items-center justify-center gap-1.5"
            style={{
              inset: CARD1_INSET,
              transform: "rotateY(180deg)",
              backfaceVisibility: "hidden",
              WebkitBackfaceVisibility: "hidden",
            }}
          >
            <Image src="/images/card1.svg" alt="" fill className="pointer-events-none absolute inset-0 -z-10 select-none" />
            <span className="text-[11px] font-bold uppercase tracking-[1.5px] text-brand-green">
              Voucher liberado 🎉
            </span>
            <p className="text-[54px] font-bold leading-none tracking-tight text-[#2f2f2f]">
              85%
            </p>
            <p className="text-[15px] font-semibold text-[#2f2f2f]">de desconto</p>
          </div>
        </motion.button>
      </div>

      <div className="min-h-[68px] w-full">
        {entranceRevealed && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <Button variant="light" onClick={handleRedeem}>
              {redeemed ? "Continuar" : "Resgatar Agora"}
            </Button>
          </motion.div>
        )}
      </div>
    </motion.div>
  );
}
