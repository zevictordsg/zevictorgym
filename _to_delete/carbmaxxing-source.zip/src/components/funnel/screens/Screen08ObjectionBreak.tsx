"use client";

import { Image as ImageIcon } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Callout } from "@/components/ui/Card";
import { CheckItem } from "@/components/ui/CheckItem";
import { ArrowRight } from "../icons";
import type { FunnelScreenProps } from "../types";

const BULLETS = [
  "Aulas onde estruturo tudo no passo a passo",
  "Sistema que te permite liberdade na dieta",
  "Distribuição correta de macros e calorias",
  "Materiais completos de acompanhamento",
  "Aulas científicas te explicando a base de tudo",
];

export function Screen08ObjectionBreak({ onNext }: FunnelScreenProps) {
  return (
    <div className="flex min-h-full flex-col gap-8 px-5 pb-8 pt-1">
      <Callout tone="amber">
        🚨 Ainda bem que você chegou até aqui, afinal quem chega cedo bebe
        água limpa🚨
      </Callout>

      {/* Placeholder — troque pela foto real usada no Figma */}
      <div className="flex h-[183px] w-full items-center justify-center rounded-[24px] bg-gradient-to-br from-[#efe4d0] to-[#d8c9a8] shadow-[0_4px_19.9px_rgba(0,0,0,0.25)]">
        <ImageIcon className="h-9 w-9 text-[#a8926a]" strokeWidth={1.5} />
      </div>

      <div className="flex flex-col gap-3 text-center">
        <p className="text-[16px] font-bold leading-[1.4] text-foreground/50">
          Copie e cole a organização de calorias e macros que me permitem
          aproveitar refs livres sem sentir culpa e ainda transformar isso em
          combustível para meus treinos!
        </p>
        <p className="text-[14px] leading-[1.4] text-[#939393]">
          Essa estrutura me fez literalmente alcançar um físico que eu só
          imaginava ter com dietas super restritivas e que me deixariam com
          fome o dia todo.
        </p>
      </div>

      <div className="flex flex-col gap-3">
        {BULLETS.map((b) => (
          <CheckItem key={b} tone="green-soft" className="py-3 text-sm">
            {b}
          </CheckItem>
        ))}
      </div>

      <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
        Quero o material mais completo!
      </Button>
    </div>
  );
}
