"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/Button";
import { Logo } from "@/components/ui/Logo";
import type { FunnelScreenProps } from "../types";

const STARS = [
  { top: "9%", left: "12%", size: 14, rotate: -15 },
  { top: "8%", right: "14%", size: 10, rotate: 20 },
  { bottom: "10%", left: "5%", size: 10, rotate: 10 },
  { bottom: "12%", right: "9%", size: 16, rotate: -8 },
];

const BARCODE_WIDTHS = [3, 1, 2, 1, 3, 2, 1, 1, 3, 2, 1, 3, 2, 1, 2, 3, 1, 2];

export function Screen07VoucherSpin({ onNext }: FunnelScreenProps) {
  const [revealed, setRevealed] = useState(false);

  return (
    <div className="relative flex h-full flex-col items-center justify-between overflow-hidden px-5 pb-8 pt-1">
      {STARS.map((s, i) => {
        const { size, rotate, ...position } = s;
        return (
          <Star
            key={i}
            className="absolute text-white/20"
            style={{ ...position, width: size, height: size, transform: `rotate(${rotate}deg)` }}
            fill="currentColor"
          />
        );
      })}

      <Logo className="text-white" />

      <div className="flex flex-col items-center gap-6">
        <div className="relative flex items-center gap-2">
          <span className="-mt-1 -rotate-[14deg] text-2xl">🎁</span>
          <div className="text-center text-[28px] font-semibold leading-[1.1] text-[#e7e7e7]">
            <p>Resgate</p>
            <p>Seu Voucher</p>
          </div>
          <span className="-mt-1 rotate-[14deg] text-2xl">🎁</span>
        </div>

        <p className="max-w-[280px] text-center text-[18px] leading-[1.4] text-[#d4d4d4]/80">
          <span className="font-bold">Restam apenas 39 Vouchers</span> até 50
          membros. Clique em Resgatar Agora.
        </p>
      </div>

      <div style={{ perspective: 1200 }}>
        <motion.button
          type="button"
          onClick={() => setRevealed(true)}
          initial={{ rotateY: 180, scale: 0.85, opacity: 0 }}
          animate={{ rotateY: 0, scale: 1, opacity: 1 }}
          transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1], delay: 0.15 }}
          onAnimationComplete={() => setRevealed(true)}
          style={{ transformStyle: "preserve-3d" }}
          className="relative flex w-[240px] flex-col items-center gap-5 rounded-[24px] border-4 border-[#3a3a3a] bg-gradient-to-b from-[#e9e9e9] to-[#c9c9c9] px-6 pb-7 pt-8 shadow-[0_20px_40px_rgba(0,0,0,0.5)]"
        >
          <span className="absolute -left-2.5 top-[calc(100%-84px)] h-5 w-5 rounded-full bg-dark-screen-bg" />
          <span className="absolute -right-2.5 top-[calc(100%-84px)] h-5 w-5 rounded-full bg-dark-screen-bg" />

          <Logo className="text-[64px] text-[#2f2f2f]" />
          <p className="text-center text-[20px] font-semibold leading-[1.1] text-[#2f2f2f]">
            Resgate
            <br />
            Seu Voucher
          </p>

          <div className="flex h-12 items-end gap-[2px] border-t border-dashed border-[#999] pt-3">
            {BARCODE_WIDTHS.map((w, i) => (
              <span
                key={i}
                className="h-8 bg-[#2f2f2f]"
                style={{ width: w }}
              />
            ))}
          </div>
        </motion.button>
      </div>

      <div className="min-h-[68px] w-full">
        {revealed && (
          <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <Button variant="light" onClick={onNext}>
              Resgatar Agora
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
