"use client";

import { useEffect, useState } from "react";
import { Play } from "lucide-react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/Button";
import { ArrowRight } from "../icons";
import type { FunnelScreenProps } from "../types";

/**
 * Tela de VSL — placeholder de vídeo ocupando a tela inteira (full-bleed).
 * Troque `videoSrc` pela URL final (Mux, Bunny, Cloudflare Stream, ou um
 * <video> com mp4) quando tiver o vídeo pronto — o layout já está pronto
 * pra tocar automaticamente nesse caso.
 */
const videoSrc: string | null = null;
const revealCtaAfterSeconds = 5;

export function Screen02VSL({ onNext }: FunnelScreenProps) {
  const [ctaVisible, setCtaVisible] = useState(false);

  useEffect(() => {
    const timer = window.setTimeout(
      () => setCtaVisible(true),
      revealCtaAfterSeconds * 1000
    );
    return () => window.clearTimeout(timer);
  }, []);

  return (
    <div className="relative h-full w-full overflow-hidden bg-black">
      {videoSrc ? (
        <video
          src={videoSrc}
          autoPlay
          muted
          playsInline
          className="h-full w-full object-cover"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center bg-gradient-to-b from-[#1c1c1c] to-black">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-white/10 text-white backdrop-blur-sm">
            <Play className="h-6 w-6 translate-x-0.5" fill="currentColor" />
          </span>
        </div>
      )}

      <div className="pointer-events-none absolute inset-x-0 bottom-0 flex justify-center px-5 pb-8">
        {ctaVisible && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="pointer-events-auto w-full"
          >
            <Button onClick={onNext} icon={<ArrowRight className="h-3.5 w-3.5" />}>
              Continuar
            </Button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
