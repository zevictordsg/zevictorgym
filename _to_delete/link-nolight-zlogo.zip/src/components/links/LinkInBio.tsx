"use client";

import { useEffect, type ComponentType, type SVGProps } from "react";
import Image from "next/image";
import { motion, type Variants } from "framer-motion";
import { ArrowRight, ArrowUpRight, FileSpreadsheet, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { DiscordIcon, InstagramIcon, TikTokIcon } from "./icons";

/**
 * Página de links pessoal ("link-in-bio") — fica na raiz do site (`/`), com
 * o funil da planilha movido pra `/planilhadohack`. Fundo `#0c0c0c` porque
 * o recorte em `public/images/link.webp` já é puro preto com alfa variável
 * (confirmado via PIL: RGB 0,0,0 em toda a borda esfumaçada) — colado sobre
 * esse tom específico, a transição do retrato pro fundo da página fica
 * costurada sem nenhuma borda visível.
 *
 * `html`/`body` (definidos no layout raiz, compartilhado com a rota clara
 * do funil) ficam brancos por padrão — sem ajuste, um "arrastão" no celular
 * (rubber-band/overscroll no iOS) revela esse branco por trás do conteúdo.
 * O `useEffect` abaixo tinge os dois de `#0c0c0c` enquanto essa tela está
 * montada e devolve a cor original ao desmontar, sem precisar duplicar o
 * layout raiz numa rota separada só por causa disso.
 *
 * Estética inspirada nas referências "Blank School" que o usuário enviou:
 * paleta quase monocromática, tipografia serifada itálica pontual (reusa
 * `font-script`/Instrument Serif já carregada pro logo do Carbmaxxing) e
 * cartões escuros com hairline — aqui adaptado pra botões de link com um
 * toque de cor por plataforma nos badges de ícone.
 */

const PAGE_BG = "#0c0c0c";

type LinkItem = {
  key: string;
  href: string;
  label: string;
  subtitle: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
  color: string;
  external: boolean;
  primary?: boolean;
};

const LINKS: LinkItem[] = [
  {
    key: "planilha",
    href: "/planilhadohack",
    label: "Planilha do Hack",
    subtitle: "Acesse gratuitamente",
    icon: FileSpreadsheet,
    color: "#34c16d",
    external: false,
    primary: true,
  },
  {
    key: "discord",
    href: "https://discord.gg/ryMeXhjW",
    label: "Comunidade no Discord",
    subtitle: "Converse com quem já aplica",
    icon: DiscordIcon,
    color: "#5865f2",
    external: true,
  },
  {
    key: "auralab",
    href: "https://apps.apple.com/br/app/auralab/id6794130003",
    label: "App AuraLab",
    subtitle: "Baixe na App Store",
    icon: Sparkles,
    color: "#a78bfa",
    external: true,
  },
  {
    key: "instagram",
    href: "https://www.instagram.com/zevictor.gym/",
    label: "Instagram",
    subtitle: "@zevictor.gym",
    icon: InstagramIcon,
    color: "#e1306c",
    external: true,
  },
  {
    key: "tiktok",
    href: "https://www.tiktok.com/@zevictor.gym",
    label: "TikTok",
    subtitle: "@zevictor.gym",
    icon: TikTokIcon,
    color: "#25f4ee",
    external: true,
  },
];

const container: Variants = {
  hidden: { opacity: 0, scale: 0.97 },
  show: {
    opacity: 1,
    scale: 1,
    transition: {
      duration: 0.6,
      ease: [0.16, 1, 0.3, 1],
      staggerChildren: 0.09,
      delayChildren: 0.25,
    },
  },
};

const item: Variants = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.55, ease: [0.16, 1, 0.3, 1] } },
};

function LinkRow({ data }: { data: LinkItem }) {
  const Icon = data.icon;
  const ArrowIcon = data.external ? ArrowUpRight : ArrowRight;

  return (
    <motion.a
      href={data.href}
      target={data.external ? "_blank" : undefined}
      rel={data.external ? "noopener noreferrer" : undefined}
      variants={item}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.97 }}
      transition={{ type: "spring", stiffness: 400, damping: 28 }}
      className={cn(
        "group relative flex w-full items-center gap-3.5 overflow-hidden rounded-[18px] border px-4 py-3.5 transition-colors duration-200",
        data.primary
          ? "border-[#34c16d]/40 bg-[#34c16d]/[0.08] shadow-[0_10px_30px_rgba(52,193,109,0.16)]"
          : "border-white/[0.08] bg-white/[0.03] hover:border-white/[0.15] hover:bg-white/[0.055]"
      )}
    >
      {data.primary && (
        <motion.span
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-[18px]"
          style={{ boxShadow: "0 0 0 1px rgba(52,193,109,0.35)" }}
          animate={{ opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
        />
      )}

      <span
        className="relative z-10 flex h-11 w-11 shrink-0 items-center justify-center rounded-[13px]"
        style={{ background: `${data.color}20`, color: data.color }}
      >
        <Icon className="h-5 w-5" />
      </span>

      <span className="relative z-10 flex min-w-0 flex-1 flex-col items-start text-left">
        <span className="text-[15px] font-semibold tracking-[-0.2px] text-white">
          {data.label}
        </span>
        <span className="text-[12px] text-white/40">{data.subtitle}</span>
      </span>

      <ArrowIcon className="relative z-10 h-4 w-4 shrink-0 text-white/30 transition-all duration-200 group-hover:translate-x-0.5 group-hover:text-white/80" />
    </motion.a>
  );
}

export function LinkInBio() {
  // Tinge html/body de #0c0c0c enquanto essa tela está montada, pra não
  // aparecer branco atrás durante o rubber-band/overscroll no mobile —
  // reverte pra cor original ao sair da rota (ex: indo pro /planilhadohack).
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    const prevRoot = root.style.backgroundColor;
    const prevBody = body.style.backgroundColor;
    root.style.backgroundColor = PAGE_BG;
    body.style.backgroundColor = PAGE_BG;
    return () => {
      root.style.backgroundColor = prevRoot;
      body.style.backgroundColor = prevBody;
    };
  }, []);

  return (
    <div className="relative min-h-dvh w-full overflow-hidden bg-[#0c0c0c]">
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="relative mx-auto flex min-h-dvh w-full max-w-[430px] flex-col items-center px-6 pb-[calc(env(safe-area-inset-bottom)+40px)] pt-[calc(env(safe-area-inset-top)+36px)]"
      >
        <motion.div variants={item} className="relative h-[27px] w-[32px]">
          <Image src="/images/zlogo.svg" alt="" fill priority className="object-contain" />
        </motion.div>

        <motion.div
          variants={item}
          animate={{ y: [0, -8, 0] }}
          transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut" }}
          className="relative mt-2 aspect-[1108/1235] w-[74vw] max-w-[300px]"
        >
          <Image
            src="/images/link.webp"
            alt="Zé Victor"
            fill
            priority
            sizes="300px"
            className="mix-blend-lighten object-contain"
          />
        </motion.div>

        <motion.div variants={item} className="-mt-2 flex flex-col items-center gap-2.5 text-center">
          <p className="text-[19px] font-semibold tracking-[-0.3px] text-white">
            @zevictor.gym
          </p>
          <p className="max-w-[280px] font-script text-[17px] italic leading-[1.4] text-white/50">
            &ldquo;Hackeando a fisiologia a favor da estética&rdquo;
          </p>
        </motion.div>

        <div className="mt-9 flex w-full flex-col gap-3">
          {LINKS.map((l) => (
            <LinkRow key={l.key} data={l} />
          ))}
        </div>

        <motion.p
          variants={item}
          className="mt-10 text-[10px] uppercase tracking-[1.5px] text-white/20"
        >
          Zé Victor © 2026
        </motion.p>
      </motion.div>
    </div>
  );
}
