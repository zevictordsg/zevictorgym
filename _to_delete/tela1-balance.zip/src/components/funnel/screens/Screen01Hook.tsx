"use client";

import Image from "next/image";
import { motion, type Variants } from "framer-motion";
import { SocialProofPill, Callout } from "@/components/ui/Card";
import { SwipeButton } from "@/components/ui/SwipeButton";
import type { FunnelScreenProps } from "../types";

const container: Variants = {
  hidden: {},
  show: {
    transition: { staggerChildren: 0.08, delayChildren: 0.05 },
  },
};

const item: Variants = {
  hidden: { opacity: 0, y: 14 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] },
  },
};

export function Screen01Hook({ onNext }: FunnelScreenProps) {
  return (
    <div className="relative flex h-full flex-col overflow-hidden bg-background">
      {/* Pattern de pontos sutil no fundo — reforça o clima "gamificado" sem
          competir com o conteúdo (o Figma em si é liso/branco aqui). */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-[0.4]"
        style={{
          backgroundImage:
            "radial-gradient(circle, rgba(0,0,0,0.08) 1px, transparent 1px)",
          backgroundSize: "16px 16px",
          maskImage:
            "radial-gradient(ellipse 100% 60% at 50% 0%, black 40%, transparent 100%)",
          WebkitMaskImage:
            "radial-gradient(ellipse 100% 60% at 50% 0%, black 40%, transparent 100%)",
        }}
      />

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="safe-top relative flex h-full min-h-0 flex-1 flex-col items-center gap-5 px-5 pb-5 pt-6"
      >
        <motion.div variants={item}>
          <SocialProofPill>
            Pessoas acessando a planilha <span className="text-foreground">+29</span>
          </SocialProofPill>
        </motion.div>

        <motion.div variants={item} className="flex justify-center gap-1">
          <div className="relative h-[158px] w-[114px] overflow-hidden rounded-[13px] bg-[#eee]">
            <Image
              src="/images/esquerda.webp"
              alt="Antes de aplicar o hack"
              fill
              sizes="114px"
              className="object-cover"
              priority
            />
          </div>
          <div className="relative h-[158px] w-[114px] overflow-hidden rounded-[13px] bg-[#eee]">
            <Image
              src="/images/direita.webp"
              alt="Depois de aplicar o hack"
              fill
              sizes="114px"
              className="object-cover"
              priority
            />
          </div>
        </motion.div>

        <motion.div variants={item} className="flex flex-col items-center gap-2 text-center">
          <h1 className="text-[24px] font-semibold leading-[1.15] tracking-tight text-foreground-strong">
            Vou te entregar o hack de macros que me fez atingir 10% de gordura
            corporal enquanto aumentei em até{" "}
            <span className="text-brand-green">1000 calorias a minha dieta!</span>
          </h1>

          <p className="text-[14px] leading-[1.35] text-foreground/50">
            Colegas que testaram essa técnica atingiram percentuais até mais
            baixos que o meu,{" "}
            <span className="font-bold text-foreground/50">
              mesmo com 2 ou 3 refeições livres na semana.
            </span>
          </p>
        </motion.div>

        <motion.div variants={item} className="w-full">
          <Callout tone="danger" className="text-[13px] font-semibold opacity-50">
            Aqui você vai ter acesso à estrutura de dieta que eu realmente testei
            na prática, não um copia do gpt.
          </Callout>
        </motion.div>

        <div className="min-h-2 flex-1" />

        <motion.div variants={item} className="flex w-full flex-col items-center gap-2.5">
          <SwipeButton label="Iniciar agora" onComplete={onNext} />

          <p className="text-[13px] text-foreground/40">Deslize pra iniciar</p>

          <div className="flex items-center gap-1">
            {[0, 1, 2].map((i) => (
              <motion.span
                key={i}
                className="flex opacity-70"
                animate={{ opacity: [0.25, 1, 0.25], x: [0, 3, 0] }}
                transition={{
                  duration: 1.4,
                  repeat: Infinity,
                  delay: i * 0.18,
                  ease: "easeInOut",
                }}
              >
                <Image src="/arrow.svg" alt="" width={7} height={11} aria-hidden />
              </motion.span>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
