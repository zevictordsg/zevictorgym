import type { Metadata, Viewport } from "next";
import { instrumentSans, logoScript } from "@/lib/fonts";
import "./globals.css";

export const metadata: Metadata = {
  title: "Carbmaxxing® — O hack de macros para secar comendo mais",
  description:
    "Descubra o hack de macros que libera até 1000kcal a mais na sua dieta sem parar de perder gordura.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#ffffff",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="pt-BR"
      className={`${instrumentSans.variable} ${logoScript.variable} h-full antialiased`}
    >
      <body className="h-full bg-background text-foreground">{children}</body>
    </html>
  );
}
